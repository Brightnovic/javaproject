public class Condition {
    public static void main(String[] args) {
        int i = 20;
        boolean isActive = false;
        String shawarma = "Beef";

        // if (i == 20) {
        //     System.out.println("i is 20");
        // } else {
        //     System.out.println("i is not 20");
        // }

        // Nested if statement
        // if (i == 20) {
        //     if (isActive == true) {
        //         if (i == 343) {
        //             System.out.println("dddd");
        //         } else {
        //             System.out.println("yyy");
        //         }
        //     } else {
        //         System.out.println("You are not active");
        //     }
        // } else {
        //     System.out.println("I is not 20");
        // }

        // If else if ladder
        // if ( i== 20) {
        //     System.out.println("ddd");
        // } else if (i == 30) {
        //     System.out.println("oil");
        // } else if (i == 90) {
        //     System.out.println("ddd");
        // } else {
        //     System.out.println("dodod");
        // }

        // switch case
        // switch(i) {
        //     case 20 -> System.out.println("20");
        //     case 30 -> System.out.println("30");
        //     default -> System.out.println("Default");
        // }

        // While Loop
        // Initialization
        int j = 0;

        // while(j <= 3) {
        //     System.out.println(j);
        //     j++;
        // }

        // do {
        //     System.out.println(j);
        //     j++;
        // } while (j >= 3);

        for (int k = 0; k <= 5; k++) {
            System.out.println(k);
        }
    }
}
